<?php 

return [
    'next' => 'Next &raquo;',
    'previous' => '&laquo; Previous',
];
